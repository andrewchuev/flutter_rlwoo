import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:woo/app_bar.dart';
import 'package:woo/list_products.dart';
import 'package:woo/models/order.dart';
import 'package:woo/provider/woo_provider.dart';

class ThankYou extends StatefulWidget {
  final String orderNumber;

  ThankYou({Key key, @required this.orderNumber}) : super(key: key);

  @override
  _ThankYouState createState() => _ThankYouState();
}

class _ThankYouState extends State<ThankYou> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: WooAppBar(context, 'Order complete'),
      body: Column(
        children: [
          Text(
            'Thank you!',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          FutureBuilder<Order>(
            future: getOrder(widget.orderNumber),
            builder: (context, snapshot) {
              if (snapshot.hasError) print(snapshot.error);
              return snapshot.hasData ? Expanded(child: orderHeader(snapshot.data.billing)) : Center(child: CircularProgressIndicator());
            },
          ),
          FutureBuilder<Order>(
            future: getOrder(widget.orderNumber),
            builder: (context, snapshot) {
              if (snapshot.hasError) print(snapshot.error);
              return snapshot.hasData
                  ? Expanded(
                      child: ListView.builder(
                          itemCount: snapshot.data.lineItems.length,
                          itemBuilder: (context, i) {
                            return Text(snapshot.data.lineItems[i]['name'] + ' - ' + snapshot.data.lineItems[i]['price'].toString());
                          }),
                    )
                  : Center(child: CircularProgressIndicator());
            },
          ),
          Consumer<WooProvider>(builder: (context, order, child) {
            return Text(
              'Total amount: ' + order.productTotal.toString(),
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 26,
              ),
            );
          }),
          FlatButton(
            child: Text('Go shop'),
            color: Colors.black12,
            onPressed: () {
              Provider.of<WooProvider>(context, listen: false).clearCart();
              Navigator.push(context, MaterialPageRoute(builder: (context) => Products()));
            },
          )
        ],
      ),
    );
  }
}

Widget orderHeader(Map<String, dynamic> billing) {
  Map<String, String> items = {};
  Map<String, String> fields = {
    'First name': 'first_name',
    'Last name': 'last_name',
    'Address': 'address',
    'City': 'city',
    'State': 'state',
    'Postcode': 'postcode',
    'Country': 'country',
    'Email': 'email',
    'Phone': 'phone',
  };

  int i = 0;
  for (var item in fields.entries) {
    //print("${item.key} - ${billing[item.value]}");
    items[item.key] = billing[item.value];
  }

  print(items);

  return ListView.builder(
    itemCount: items.length,
    itemBuilder: (BuildContext context, int index) {
      String key = items.keys.elementAt(index);
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Column(
            children: [
              Text("$key"),
            ],
          ),
          Column(
            children: [
              Text("${items[key]}"),
            ],
          ),
        ],
      );
    },
  );
}
