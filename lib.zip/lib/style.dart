import 'package:flutter/material.dart';

const h1 = TextStyle(fontSize: 35, fontWeight: FontWeight.w900, color: Colors.black);
const h2 = TextStyle(fontSize: 18.0, fontWeight: FontWeight.w500, color: Colors.black);